<?php
    Class Producto{
        public $id;
        public $nombre;
        public $referencia;
        public $precio;
        public $peso;
        public $categoria;
        public $stock;
        public $fecha_creacion;
    }